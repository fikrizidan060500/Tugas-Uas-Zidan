package com.example.data;

import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Data {
    private @Id @GeneratedValue Long id;
    private Long isbn;
    private String judul;
    private String penerbit;
    private String tahun;
    private String harga;
    private Long jumlahhalaman;

    Data() {
    }

    Data(Long isbn, String judul, String penerbit, String tahun, String harga, Long jumlahhalaman) {
        this.isbn = isbn;
        this.judul = judul;
        this.penerbit = penerbit;
        this.tahun = tahun;
        this.harga = harga;
        this.jumlahhalaman = jumlahhalaman;
    }

    public Long getId() {
        return this.id;
    }

    public Long getisbn() {
        return this.isbn;
    }

    public String getjudul() {
        return this.judul;
    }

    public String getpenerbit() {
        return this.penerbit;
    }

    public String gettahun() {
        return this.tahun;
    }

    public String getharga() {
        return this.harga;
    }

    public Long getjumlahhalaman() {
        return this.jumlahhalaman;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void setisbn(Long isbn) {
        this.isbn = isbn;
    }

    public void setjudul(String judul) {
        this.judul = judul;
    }

    public void setpenerbit(String penerbit) {
        this.penerbit = penerbit;
    }

    public void settahun(String tahun) {
        this.tahun = tahun;
    }

    public void setharga(String harga) {
        this.harga = harga;
    }

    public void setGaji(Long jumlahhalaman) {
        this.jumlahhalaman = jumlahhalaman;
    }

    @Override
    public boolean equals(Object o) {

        if (this == o)
            return true;
        if (!(o instanceof Data))
            return false;
        Data data = (Data) o;
        return Objects.equals(this.id, data.id) && Objects.equals(this.isbn, data.isbn)
                && Objects.equals(this.judul, data.judul) && Objects.equals(this.penerbit, data.penerbit)
                && Objects.equals(this.tahun, data.tahun) && Objects.equals(this.harga, data.harga)
                && Objects.equals(this.jumlahhalaman, data.jumlahhalaman);

    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id, this.isbn, this.judul, this.penerbit, this.tahun, this.harga, this.jumlahhalaman);
    }

    @Override
    public String toString() {
        return "Data buku{" + "id=" + this.id + ", isbn='" + this.isbn + '\'' + ", judul='" + this.judul + '\''
                + ", penerbit='" + this.penerbit + '\'' + ", tahun='" + this.tahun + '\'' + ", harga='"
                + this.harga + '\'' + ", jumlahhalaman='" + this.jumlahhalaman + '\'' +  '}';
    }

}
